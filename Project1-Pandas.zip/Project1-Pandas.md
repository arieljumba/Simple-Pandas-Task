```python
import pandas as pd
import os as os

os.chdir("E:\python\PROJECTS\S_LYTICS")
files = [file for file in os.listdir()]
all_data = pd.DataFrame()
for file in files:
    df = pd.read_csv("./"+file)
    all_data = pd.concat([all_data,df])
    
df = all_data
df.head(5)

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Product</th>
      <th>Quantity Ordered</th>
      <th>Price Each</th>
      <th>Order Date</th>
      <th>Purchase Address</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>176558</td>
      <td>USB-C Charging Cable</td>
      <td>2</td>
      <td>11.95</td>
      <td>04/19/19 08:46</td>
      <td>917 1st St, Dallas, TX 75001</td>
    </tr>
    <tr>
      <th>2</th>
      <td>176559</td>
      <td>Bose SoundSport Headphones</td>
      <td>1</td>
      <td>99.99</td>
      <td>04/07/19 22:30</td>
      <td>682 Chestnut St, Boston, MA 02215</td>
    </tr>
    <tr>
      <th>3</th>
      <td>176560</td>
      <td>Google Phone</td>
      <td>1</td>
      <td>600</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
    </tr>
    <tr>
      <th>4</th>
      <td>176560</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>11.99</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
    </tr>
    <tr>
      <th>5</th>
      <td>176561</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>11.99</td>
      <td>04/30/19 09:27</td>
      <td>333 8th St, Los Angeles, CA 90001</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>11681</th>
      <td>259353</td>
      <td>AAA Batteries (4-pack)</td>
      <td>3</td>
      <td>2.99</td>
      <td>09/17/19 20:56</td>
      <td>840 Highland St, Los Angeles, CA 90001</td>
    </tr>
    <tr>
      <th>11682</th>
      <td>259354</td>
      <td>iPhone</td>
      <td>1</td>
      <td>700</td>
      <td>09/01/19 16:00</td>
      <td>216 Dogwood St, San Francisco, CA 94016</td>
    </tr>
    <tr>
      <th>11683</th>
      <td>259355</td>
      <td>iPhone</td>
      <td>1</td>
      <td>700</td>
      <td>09/23/19 07:39</td>
      <td>220 12th St, San Francisco, CA 94016</td>
    </tr>
    <tr>
      <th>11684</th>
      <td>259356</td>
      <td>34in Ultrawide Monitor</td>
      <td>1</td>
      <td>379.99</td>
      <td>09/19/19 17:30</td>
      <td>511 Forest St, San Francisco, CA 94016</td>
    </tr>
    <tr>
      <th>11685</th>
      <td>259357</td>
      <td>USB-C Charging Cable</td>
      <td>1</td>
      <td>11.95</td>
      <td>09/30/19 00:18</td>
      <td>250 Meadow St, San Francisco, CA 94016</td>
    </tr>
  </tbody>
</table>
<p>186305 rows × 6 columns</p>
</div>




```python

```


```python

```


```python
df["Month"] = df["Order Date"].str[0:2]
df = df.dropna(how = "all")
df = df[df["Month"].str[0:2] != "Or"]
df.head()
```

    <ipython-input-15-c88ec7939b8d>:1: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df["Month"] = df["Order Date"].str[0:2]
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Product</th>
      <th>Quantity Ordered</th>
      <th>Price Each</th>
      <th>Order Date</th>
      <th>Purchase Address</th>
      <th>Month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>176558</td>
      <td>USB-C Charging Cable</td>
      <td>2</td>
      <td>11.95</td>
      <td>04/19/19 08:46</td>
      <td>917 1st St, Dallas, TX 75001</td>
      <td>04</td>
    </tr>
    <tr>
      <th>2</th>
      <td>176559</td>
      <td>Bose SoundSport Headphones</td>
      <td>1</td>
      <td>99.99</td>
      <td>04/07/19 22:30</td>
      <td>682 Chestnut St, Boston, MA 02215</td>
      <td>04</td>
    </tr>
    <tr>
      <th>3</th>
      <td>176560</td>
      <td>Google Phone</td>
      <td>1</td>
      <td>600</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>04</td>
    </tr>
    <tr>
      <th>4</th>
      <td>176560</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>11.99</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>04</td>
    </tr>
    <tr>
      <th>5</th>
      <td>176561</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>11.99</td>
      <td>04/30/19 09:27</td>
      <td>333 8th St, Los Angeles, CA 90001</td>
      <td>04</td>
    </tr>
  </tbody>
</table>
</div>




```python
df["Month"].describe()
df["Month"] = df["Month"].astype("int")
df["Month"].describe()
df["Price Each"] = pd.to_numeric(df["Price Each"])
df["Quantity Ordered"] = pd.to_numeric(df["Quantity Ordered"])
df["Price Each"].describe()
```




    count    185950.000000
    mean        184.399735
    std         332.731330
    min           2.990000
    25%          11.950000
    50%          14.950000
    75%         150.000000
    max        1700.000000
    Name: Price Each, dtype: float64




```python
import numpy as np
new_data = np.random.randint(1,12, size = 185949)
new_data = pd.DataFrame(new_data,columns = ["Month2"])
df["Sales Month"] = new_data
pd.options.display.float_format = "{:,.0f}".format
df.groupby("Sales Month").sum()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Quantity Ordered</th>
      <th>Price Each</th>
      <th>Month</th>
    </tr>
    <tr>
      <th>Sales Month</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>18296</td>
      <td>2,997,873</td>
      <td>115544</td>
    </tr>
    <tr>
      <th>2</th>
      <td>18626</td>
      <td>3,047,215</td>
      <td>116272</td>
    </tr>
    <tr>
      <th>3</th>
      <td>19691</td>
      <td>3,240,166</td>
      <td>124015</td>
    </tr>
    <tr>
      <th>4</th>
      <td>18821</td>
      <td>3,034,461</td>
      <td>117698</td>
    </tr>
    <tr>
      <th>5</th>
      <td>19072</td>
      <td>3,126,820</td>
      <td>119145</td>
    </tr>
    <tr>
      <th>6</th>
      <td>19244</td>
      <td>3,241,531</td>
      <td>120960</td>
    </tr>
    <tr>
      <th>7</th>
      <td>19320</td>
      <td>3,205,451</td>
      <td>121198</td>
    </tr>
    <tr>
      <th>8</th>
      <td>18652</td>
      <td>2,991,996</td>
      <td>117809</td>
    </tr>
    <tr>
      <th>9</th>
      <td>18444</td>
      <td>3,057,558</td>
      <td>116083</td>
    </tr>
    <tr>
      <th>10</th>
      <td>19704</td>
      <td>3,212,163</td>
      <td>123711</td>
    </tr>
    <tr>
      <th>11</th>
      <td>19209</td>
      <td>3,133,896</td>
      <td>120212</td>
    </tr>
  </tbody>
</table>
</div>




```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Product</th>
      <th>Quantity Ordered</th>
      <th>Price Each</th>
      <th>Order Date</th>
      <th>Purchase Address</th>
      <th>Month</th>
      <th>Sales Month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>176558</td>
      <td>USB-C Charging Cable</td>
      <td>2</td>
      <td>12</td>
      <td>04/19/19 08:46</td>
      <td>917 1st St, Dallas, TX 75001</td>
      <td>4</td>
      <td>4</td>
    </tr>
    <tr>
      <th>2</th>
      <td>176559</td>
      <td>Bose SoundSport Headphones</td>
      <td>1</td>
      <td>100</td>
      <td>04/07/19 22:30</td>
      <td>682 Chestnut St, Boston, MA 02215</td>
      <td>4</td>
      <td>6</td>
    </tr>
    <tr>
      <th>3</th>
      <td>176560</td>
      <td>Google Phone</td>
      <td>1</td>
      <td>600</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>6</td>
    </tr>
    <tr>
      <th>4</th>
      <td>176560</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>12</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>6</td>
    </tr>
    <tr>
      <th>5</th>
      <td>176561</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>12</td>
      <td>04/30/19 09:27</td>
      <td>333 8th St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>8</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>11681</th>
      <td>259353</td>
      <td>AAA Batteries (4-pack)</td>
      <td>3</td>
      <td>3</td>
      <td>09/17/19 20:56</td>
      <td>840 Highland St, Los Angeles, CA 90001</td>
      <td>9</td>
      <td>11</td>
    </tr>
    <tr>
      <th>11682</th>
      <td>259354</td>
      <td>iPhone</td>
      <td>1</td>
      <td>700</td>
      <td>09/01/19 16:00</td>
      <td>216 Dogwood St, San Francisco, CA 94016</td>
      <td>9</td>
      <td>7</td>
    </tr>
    <tr>
      <th>11683</th>
      <td>259355</td>
      <td>iPhone</td>
      <td>1</td>
      <td>700</td>
      <td>09/23/19 07:39</td>
      <td>220 12th St, San Francisco, CA 94016</td>
      <td>9</td>
      <td>5</td>
    </tr>
    <tr>
      <th>11684</th>
      <td>259356</td>
      <td>34in Ultrawide Monitor</td>
      <td>1</td>
      <td>380</td>
      <td>09/19/19 17:30</td>
      <td>511 Forest St, San Francisco, CA 94016</td>
      <td>9</td>
      <td>7</td>
    </tr>
    <tr>
      <th>11685</th>
      <td>259357</td>
      <td>USB-C Charging Cable</td>
      <td>1</td>
      <td>12</td>
      <td>09/30/19 00:18</td>
      <td>250 Meadow St, San Francisco, CA 94016</td>
      <td>9</td>
      <td>6</td>
    </tr>
  </tbody>
</table>
<p>185950 rows × 8 columns</p>
</div>




```python
def get_city(address):
    return address.split(",")[1]
def get_state(address):
    return address.split(",")[2].split(" ")[1]

df["City"] = df["Purchase Address"].apply(lambda x: get_city(x) + " (" + get_state(x) + ") ")
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Product</th>
      <th>Quantity Ordered</th>
      <th>Price Each</th>
      <th>Order Date</th>
      <th>Purchase Address</th>
      <th>Month</th>
      <th>Sales Month</th>
      <th>City</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>176558</td>
      <td>USB-C Charging Cable</td>
      <td>2</td>
      <td>12</td>
      <td>04/19/19 08:46</td>
      <td>917 1st St, Dallas, TX 75001</td>
      <td>4</td>
      <td>4</td>
      <td>Dallas (TX)</td>
    </tr>
    <tr>
      <th>2</th>
      <td>176559</td>
      <td>Bose SoundSport Headphones</td>
      <td>1</td>
      <td>100</td>
      <td>04/07/19 22:30</td>
      <td>682 Chestnut St, Boston, MA 02215</td>
      <td>4</td>
      <td>6</td>
      <td>Boston (MA)</td>
    </tr>
    <tr>
      <th>3</th>
      <td>176560</td>
      <td>Google Phone</td>
      <td>1</td>
      <td>600</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>6</td>
      <td>Los Angeles (CA)</td>
    </tr>
    <tr>
      <th>4</th>
      <td>176560</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>12</td>
      <td>04/12/19 14:38</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>6</td>
      <td>Los Angeles (CA)</td>
    </tr>
    <tr>
      <th>5</th>
      <td>176561</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>12</td>
      <td>04/30/19 09:27</td>
      <td>333 8th St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>8</td>
      <td>Los Angeles (CA)</td>
    </tr>
  </tbody>
</table>
</div>




```python
results = df.groupby("City").sum()
results
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Quantity Ordered</th>
      <th>Price Each</th>
      <th>Month</th>
      <th>Sales Month</th>
    </tr>
    <tr>
      <th>City</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Atlanta (GA)</th>
      <td>16602</td>
      <td>2,779,908</td>
      <td>104794</td>
      <td>89841</td>
    </tr>
    <tr>
      <th>Austin (TX)</th>
      <td>11153</td>
      <td>1,809,874</td>
      <td>69829</td>
      <td>60302</td>
    </tr>
    <tr>
      <th>Boston (MA)</th>
      <td>22528</td>
      <td>3,637,410</td>
      <td>141112</td>
      <td>120444</td>
    </tr>
    <tr>
      <th>Dallas (TX)</th>
      <td>16730</td>
      <td>2,752,628</td>
      <td>104620</td>
      <td>89166</td>
    </tr>
    <tr>
      <th>Los Angeles (CA)</th>
      <td>33289</td>
      <td>5,421,435</td>
      <td>208325</td>
      <td>177816</td>
    </tr>
    <tr>
      <th>New York City (NY)</th>
      <td>27932</td>
      <td>4,635,371</td>
      <td>175741</td>
      <td>149621</td>
    </tr>
    <tr>
      <th>Portland (ME)</th>
      <td>2750</td>
      <td>447,189</td>
      <td>17144</td>
      <td>14399</td>
    </tr>
    <tr>
      <th>Portland (OR)</th>
      <td>11303</td>
      <td>1,860,558</td>
      <td>70621</td>
      <td>60139</td>
    </tr>
    <tr>
      <th>San Francisco (CA)</th>
      <td>50239</td>
      <td>8,211,462</td>
      <td>315520</td>
      <td>269779</td>
    </tr>
    <tr>
      <th>Seattle (WA)</th>
      <td>16553</td>
      <td>2,733,296</td>
      <td>104941</td>
      <td>88406</td>
    </tr>
  </tbody>
</table>
</div>




```python
import matplotlib.pyplot as plt

cities = [City for City, df in df.groupby("City")]
plt.bar(cities, results["Price Each"])
plt.xticks(cities, rotation = "vertical", size = 10)
plt.xlabel("cities")
plt.ylabel("Price")
plt.show
```




    <function matplotlib.pyplot.show(*args, **kw)>




![png](output_9_1.png)



```python
df["Order Date"] = pd.to_datetime(df["Order Date"])
df["Order Date"]
```




    0       2019-04-19 08:46:00
    2       2019-04-07 22:30:00
    3       2019-04-12 14:38:00
    4       2019-04-12 14:38:00
    5       2019-04-30 09:27:00
                    ...        
    11681   2019-09-17 20:56:00
    11682   2019-09-01 16:00:00
    11683   2019-09-23 07:39:00
    11684   2019-09-19 17:30:00
    11685   2019-09-30 00:18:00
    Name: Order Date, Length: 185950, dtype: datetime64[ns]




```python
df["Hour"] = df["Order Date"].dt.hour
df["Minute"] = df["Order Date"].dt.minute
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Product</th>
      <th>Quantity Ordered</th>
      <th>Price Each</th>
      <th>Order Date</th>
      <th>Purchase Address</th>
      <th>Month</th>
      <th>Sales Month</th>
      <th>City</th>
      <th>Hour</th>
      <th>Minute</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>176558</td>
      <td>USB-C Charging Cable</td>
      <td>2</td>
      <td>12</td>
      <td>2019-04-19 08:46:00</td>
      <td>917 1st St, Dallas, TX 75001</td>
      <td>4</td>
      <td>4</td>
      <td>Dallas (TX)</td>
      <td>8</td>
      <td>46</td>
    </tr>
    <tr>
      <th>2</th>
      <td>176559</td>
      <td>Bose SoundSport Headphones</td>
      <td>1</td>
      <td>100</td>
      <td>2019-04-07 22:30:00</td>
      <td>682 Chestnut St, Boston, MA 02215</td>
      <td>4</td>
      <td>6</td>
      <td>Boston (MA)</td>
      <td>22</td>
      <td>30</td>
    </tr>
    <tr>
      <th>3</th>
      <td>176560</td>
      <td>Google Phone</td>
      <td>1</td>
      <td>600</td>
      <td>2019-04-12 14:38:00</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>6</td>
      <td>Los Angeles (CA)</td>
      <td>14</td>
      <td>38</td>
    </tr>
    <tr>
      <th>4</th>
      <td>176560</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>12</td>
      <td>2019-04-12 14:38:00</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>6</td>
      <td>Los Angeles (CA)</td>
      <td>14</td>
      <td>38</td>
    </tr>
    <tr>
      <th>5</th>
      <td>176561</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>12</td>
      <td>2019-04-30 09:27:00</td>
      <td>333 8th St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>8</td>
      <td>Los Angeles (CA)</td>
      <td>9</td>
      <td>27</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>11681</th>
      <td>259353</td>
      <td>AAA Batteries (4-pack)</td>
      <td>3</td>
      <td>3</td>
      <td>2019-09-17 20:56:00</td>
      <td>840 Highland St, Los Angeles, CA 90001</td>
      <td>9</td>
      <td>11</td>
      <td>Los Angeles (CA)</td>
      <td>20</td>
      <td>56</td>
    </tr>
    <tr>
      <th>11682</th>
      <td>259354</td>
      <td>iPhone</td>
      <td>1</td>
      <td>700</td>
      <td>2019-09-01 16:00:00</td>
      <td>216 Dogwood St, San Francisco, CA 94016</td>
      <td>9</td>
      <td>7</td>
      <td>San Francisco (CA)</td>
      <td>16</td>
      <td>0</td>
    </tr>
    <tr>
      <th>11683</th>
      <td>259355</td>
      <td>iPhone</td>
      <td>1</td>
      <td>700</td>
      <td>2019-09-23 07:39:00</td>
      <td>220 12th St, San Francisco, CA 94016</td>
      <td>9</td>
      <td>5</td>
      <td>San Francisco (CA)</td>
      <td>7</td>
      <td>39</td>
    </tr>
    <tr>
      <th>11684</th>
      <td>259356</td>
      <td>34in Ultrawide Monitor</td>
      <td>1</td>
      <td>380</td>
      <td>2019-09-19 17:30:00</td>
      <td>511 Forest St, San Francisco, CA 94016</td>
      <td>9</td>
      <td>7</td>
      <td>San Francisco (CA)</td>
      <td>17</td>
      <td>30</td>
    </tr>
    <tr>
      <th>11685</th>
      <td>259357</td>
      <td>USB-C Charging Cable</td>
      <td>1</td>
      <td>12</td>
      <td>2019-09-30 00:18:00</td>
      <td>250 Meadow St, San Francisco, CA 94016</td>
      <td>9</td>
      <td>6</td>
      <td>San Francisco (CA)</td>
      <td>0</td>
      <td>18</td>
    </tr>
  </tbody>
</table>
<p>185950 rows × 11 columns</p>
</div>




```python
hours = [Hour for Hour, df in df.groupby("Hour")]
minutes = [Minute for Minute, df in df.groupby("Minute")]
results = df.groupby("Hour").count()

import matplotlib.pyplot as plt

plt.plot(hours, results["Price Each"])
plt.xticks(hours,rotation = "horizontal", size = 10)
plt.xlabel("hours")
plt.ylabel("Prices")
plt.grid()
plt.show()
```


![png](output_12_0.png)


#### What Sold were mostly sold together?


```python
df2 = df[df["Order ID"].duplicated(keep = False)]
df["Grouped"] = df.groupby("Order ID")["Product"].transform(lambda x: ",".join(x))
df.head(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Product</th>
      <th>Quantity Ordered</th>
      <th>Price Each</th>
      <th>Order Date</th>
      <th>Purchase Address</th>
      <th>Month</th>
      <th>Sales Month</th>
      <th>City</th>
      <th>Hour</th>
      <th>Minute</th>
      <th>Grouped</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>176558</td>
      <td>USB-C Charging Cable</td>
      <td>2</td>
      <td>12</td>
      <td>2019-04-19 08:46:00</td>
      <td>917 1st St, Dallas, TX 75001</td>
      <td>4</td>
      <td>4</td>
      <td>Dallas (TX)</td>
      <td>8</td>
      <td>46</td>
      <td>USB-C Charging Cable</td>
    </tr>
    <tr>
      <th>2</th>
      <td>176559</td>
      <td>Bose SoundSport Headphones</td>
      <td>1</td>
      <td>100</td>
      <td>2019-04-07 22:30:00</td>
      <td>682 Chestnut St, Boston, MA 02215</td>
      <td>4</td>
      <td>6</td>
      <td>Boston (MA)</td>
      <td>22</td>
      <td>30</td>
      <td>Bose SoundSport Headphones</td>
    </tr>
    <tr>
      <th>3</th>
      <td>176560</td>
      <td>Google Phone</td>
      <td>1</td>
      <td>600</td>
      <td>2019-04-12 14:38:00</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>6</td>
      <td>Los Angeles (CA)</td>
      <td>14</td>
      <td>38</td>
      <td>Google Phone,Wired Headphones</td>
    </tr>
    <tr>
      <th>4</th>
      <td>176560</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>12</td>
      <td>2019-04-12 14:38:00</td>
      <td>669 Spruce St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>6</td>
      <td>Los Angeles (CA)</td>
      <td>14</td>
      <td>38</td>
      <td>Google Phone,Wired Headphones</td>
    </tr>
    <tr>
      <th>5</th>
      <td>176561</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>12</td>
      <td>2019-04-30 09:27:00</td>
      <td>333 8th St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>8</td>
      <td>Los Angeles (CA)</td>
      <td>9</td>
      <td>27</td>
      <td>Wired Headphones</td>
    </tr>
    <tr>
      <th>6</th>
      <td>176562</td>
      <td>USB-C Charging Cable</td>
      <td>1</td>
      <td>12</td>
      <td>2019-04-29 13:03:00</td>
      <td>381 Wilson St, San Francisco, CA 94016</td>
      <td>4</td>
      <td>6</td>
      <td>San Francisco (CA)</td>
      <td>13</td>
      <td>3</td>
      <td>USB-C Charging Cable</td>
    </tr>
    <tr>
      <th>7</th>
      <td>176563</td>
      <td>Bose SoundSport Headphones</td>
      <td>1</td>
      <td>100</td>
      <td>2019-04-02 07:46:00</td>
      <td>668 Center St, Seattle, WA 98101</td>
      <td>4</td>
      <td>11</td>
      <td>Seattle (WA)</td>
      <td>7</td>
      <td>46</td>
      <td>Bose SoundSport Headphones</td>
    </tr>
    <tr>
      <th>8</th>
      <td>176564</td>
      <td>USB-C Charging Cable</td>
      <td>1</td>
      <td>12</td>
      <td>2019-04-12 10:58:00</td>
      <td>790 Ridge St, Atlanta, GA 30301</td>
      <td>4</td>
      <td>10</td>
      <td>Atlanta (GA)</td>
      <td>10</td>
      <td>58</td>
      <td>USB-C Charging Cable</td>
    </tr>
    <tr>
      <th>9</th>
      <td>176565</td>
      <td>Macbook Pro Laptop</td>
      <td>1</td>
      <td>1,700</td>
      <td>2019-04-24 10:38:00</td>
      <td>915 Willow St, San Francisco, CA 94016</td>
      <td>4</td>
      <td>9</td>
      <td>San Francisco (CA)</td>
      <td>10</td>
      <td>38</td>
      <td>Macbook Pro Laptop</td>
    </tr>
    <tr>
      <th>10</th>
      <td>176566</td>
      <td>Wired Headphones</td>
      <td>1</td>
      <td>12</td>
      <td>2019-04-08 14:05:00</td>
      <td>83 7th St, Boston, MA 02215</td>
      <td>4</td>
      <td>4</td>
      <td>Boston (MA)</td>
      <td>14</td>
      <td>5</td>
      <td>Wired Headphones</td>
    </tr>
    <tr>
      <th>11</th>
      <td>176567</td>
      <td>Google Phone</td>
      <td>1</td>
      <td>600</td>
      <td>2019-04-18 17:18:00</td>
      <td>444 7th St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>10</td>
      <td>Los Angeles (CA)</td>
      <td>17</td>
      <td>18</td>
      <td>Google Phone</td>
    </tr>
    <tr>
      <th>12</th>
      <td>176568</td>
      <td>Lightning Charging Cable</td>
      <td>1</td>
      <td>15</td>
      <td>2019-04-15 12:18:00</td>
      <td>438 Elm St, Seattle, WA 98101</td>
      <td>4</td>
      <td>6</td>
      <td>Seattle (WA)</td>
      <td>12</td>
      <td>18</td>
      <td>Lightning Charging Cable</td>
    </tr>
    <tr>
      <th>13</th>
      <td>176569</td>
      <td>27in 4K Gaming Monitor</td>
      <td>1</td>
      <td>390</td>
      <td>2019-04-16 19:23:00</td>
      <td>657 Hill St, Dallas, TX 75001</td>
      <td>4</td>
      <td>3</td>
      <td>Dallas (TX)</td>
      <td>19</td>
      <td>23</td>
      <td>27in 4K Gaming Monitor</td>
    </tr>
    <tr>
      <th>14</th>
      <td>176570</td>
      <td>AA Batteries (4-pack)</td>
      <td>1</td>
      <td>4</td>
      <td>2019-04-22 15:09:00</td>
      <td>186 12th St, Dallas, TX 75001</td>
      <td>4</td>
      <td>1</td>
      <td>Dallas (TX)</td>
      <td>15</td>
      <td>9</td>
      <td>AA Batteries (4-pack)</td>
    </tr>
    <tr>
      <th>15</th>
      <td>176571</td>
      <td>Lightning Charging Cable</td>
      <td>1</td>
      <td>15</td>
      <td>2019-04-19 14:29:00</td>
      <td>253 Johnson St, Atlanta, GA 30301</td>
      <td>4</td>
      <td>3</td>
      <td>Atlanta (GA)</td>
      <td>14</td>
      <td>29</td>
      <td>Lightning Charging Cable</td>
    </tr>
    <tr>
      <th>16</th>
      <td>176572</td>
      <td>Apple Airpods Headphones</td>
      <td>1</td>
      <td>150</td>
      <td>2019-04-04 20:30:00</td>
      <td>149 Dogwood St, New York City, NY 10001</td>
      <td>4</td>
      <td>4</td>
      <td>New York City (NY)</td>
      <td>20</td>
      <td>30</td>
      <td>Apple Airpods Headphones</td>
    </tr>
    <tr>
      <th>17</th>
      <td>176573</td>
      <td>USB-C Charging Cable</td>
      <td>1</td>
      <td>12</td>
      <td>2019-04-27 18:41:00</td>
      <td>214 Chestnut St, San Francisco, CA 94016</td>
      <td>4</td>
      <td>1</td>
      <td>San Francisco (CA)</td>
      <td>18</td>
      <td>41</td>
      <td>USB-C Charging Cable</td>
    </tr>
    <tr>
      <th>18</th>
      <td>176574</td>
      <td>Google Phone</td>
      <td>1</td>
      <td>600</td>
      <td>2019-04-03 19:42:00</td>
      <td>20 Hill St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>8</td>
      <td>Los Angeles (CA)</td>
      <td>19</td>
      <td>42</td>
      <td>Google Phone,USB-C Charging Cable</td>
    </tr>
    <tr>
      <th>19</th>
      <td>176574</td>
      <td>USB-C Charging Cable</td>
      <td>1</td>
      <td>12</td>
      <td>2019-04-03 19:42:00</td>
      <td>20 Hill St, Los Angeles, CA 90001</td>
      <td>4</td>
      <td>2</td>
      <td>Los Angeles (CA)</td>
      <td>19</td>
      <td>42</td>
      <td>Google Phone,USB-C Charging Cable</td>
    </tr>
    <tr>
      <th>20</th>
      <td>176575</td>
      <td>AAA Batteries (4-pack)</td>
      <td>1</td>
      <td>3</td>
      <td>2019-04-27 00:30:00</td>
      <td>433 Hill St, New York City, NY 10001</td>
      <td>4</td>
      <td>9</td>
      <td>New York City (NY)</td>
      <td>0</td>
      <td>30</td>
      <td>AAA Batteries (4-pack)</td>
    </tr>
  </tbody>
</table>
</div>




```python
df3 = df[df["Order ID"].duplicated(keep = False)]
df3.head(10)
df3["Grouped"] = df3.groupby("Order ID")["Product"].transform(lambda x: ",".join(x))
df3.head(20)

results = df3.groupby("Grouped").agg({
    "Price Each" : "count"
})
results = results.sort_values("Price Each", ascending = False)
results
```

    <ipython-input-136-cd6acf9b785c>:3: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      df3["Grouped"] = df3.groupby("Order ID")["Product"].transform(lambda x: ",".join(x))
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Price Each</th>
    </tr>
    <tr>
      <th>Grouped</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>iPhone,Lightning Charging Cable</th>
      <td>1764</td>
    </tr>
    <tr>
      <th>Google Phone,USB-C Charging Cable</th>
      <td>1712</td>
    </tr>
    <tr>
      <th>iPhone,Wired Headphones</th>
      <td>722</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,USB-C Charging Cable</th>
      <td>624</td>
    </tr>
    <tr>
      <th>Google Phone,Wired Headphones</th>
      <td>606</td>
    </tr>
    <tr>
      <th>iPhone,Apple Airpods Headphones</th>
      <td>572</td>
    </tr>
    <tr>
      <th>Google Phone,Bose SoundSport Headphones</th>
      <td>322</td>
    </tr>
    <tr>
      <th>Google Phone,USB-C Charging Cable,Wired Headphones</th>
      <td>231</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,Wired Headphones</th>
      <td>208</td>
    </tr>
    <tr>
      <th>iPhone,Lightning Charging Cable,Wired Headphones</th>
      <td>168</td>
    </tr>
    <tr>
      <th>iPhone,Lightning Charging Cable,Apple Airpods Headphones</th>
      <td>129</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,Bose SoundSport Headphones</th>
      <td>120</td>
    </tr>
    <tr>
      <th>Lightning Charging Cable,USB-C Charging Cable</th>
      <td>110</td>
    </tr>
    <tr>
      <th>Lightning Charging Cable,AA Batteries (4-pack)</th>
      <td>104</td>
    </tr>
    <tr>
      <th>Lightning Charging Cable,Lightning Charging Cable</th>
      <td>102</td>
    </tr>
    <tr>
      <th>AA Batteries (4-pack),Lightning Charging Cable</th>
      <td>102</td>
    </tr>
    <tr>
      <th>AAA Batteries (4-pack),USB-C Charging Cable</th>
      <td>100</td>
    </tr>
    <tr>
      <th>AAA Batteries (4-pack),AAA Batteries (4-pack)</th>
      <td>96</td>
    </tr>
    <tr>
      <th>AA Batteries (4-pack),AAA Batteries (4-pack)</th>
      <td>96</td>
    </tr>
    <tr>
      <th>Google Phone,USB-C Charging Cable,Bose SoundSport Headphones</th>
      <td>93</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,USB-C Charging Cable,Wired Headphones</th>
      <td>93</td>
    </tr>
    <tr>
      <th>USB-C Charging Cable,USB-C Charging Cable</th>
      <td>92</td>
    </tr>
    <tr>
      <th>Apple Airpods Headphones,AAA Batteries (4-pack)</th>
      <td>90</td>
    </tr>
    <tr>
      <th>AA Batteries (4-pack),Wired Headphones</th>
      <td>88</td>
    </tr>
    <tr>
      <th>AAA Batteries (4-pack),Lightning Charging Cable</th>
      <td>88</td>
    </tr>
    <tr>
      <th>AAA Batteries (4-pack),Wired Headphones</th>
      <td>86</td>
    </tr>
    <tr>
      <th>Wired Headphones,AAA Batteries (4-pack)</th>
      <td>86</td>
    </tr>
    <tr>
      <th>USB-C Charging Cable,AAA Batteries (4-pack)</th>
      <td>84</td>
    </tr>
    <tr>
      <th>Wired Headphones,USB-C Charging Cable</th>
      <td>84</td>
    </tr>
    <tr>
      <th>Apple Airpods Headphones,Wired Headphones</th>
      <td>84</td>
    </tr>
    <tr>
      <th>USB-C Charging Cable,Lightning Charging Cable</th>
      <td>82</td>
    </tr>
    <tr>
      <th>AA Batteries (4-pack),Apple Airpods Headphones</th>
      <td>82</td>
    </tr>
    <tr>
      <th>USB-C Charging Cable,Wired Headphones</th>
      <td>80</td>
    </tr>
    <tr>
      <th>AAA Batteries (4-pack),AA Batteries (4-pack)</th>
      <td>78</td>
    </tr>
    <tr>
      <th>Lightning Charging Cable,Bose SoundSport Headphones</th>
      <td>78</td>
    </tr>
    <tr>
      <th>AA Batteries (4-pack),USB-C Charging Cable</th>
      <td>74</td>
    </tr>
    <tr>
      <th>Bose SoundSport Headphones,AAA Batteries (4-pack)</th>
      <td>74</td>
    </tr>
    <tr>
      <th>Wired Headphones,AA Batteries (4-pack)</th>
      <td>72</td>
    </tr>
    <tr>
      <th>Wired Headphones,Lightning Charging Cable</th>
      <td>72</td>
    </tr>
    <tr>
      <th>USB-C Charging Cable,AA Batteries (4-pack)</th>
      <td>70</td>
    </tr>
    <tr>
      <th>Apple Airpods Headphones,Lightning Charging Cable</th>
      <td>70</td>
    </tr>
    <tr>
      <th>Lightning Charging Cable,AAA Batteries (4-pack)</th>
      <td>70</td>
    </tr>
    <tr>
      <th>AA Batteries (4-pack),AA Batteries (4-pack)</th>
      <td>70</td>
    </tr>
    <tr>
      <th>iPhone,Apple Airpods Headphones,Wired Headphones</th>
      <td>69</td>
    </tr>
    <tr>
      <th>Lightning Charging Cable,Apple Airpods Headphones</th>
      <td>68</td>
    </tr>
    <tr>
      <th>Wired Headphones,Wired Headphones</th>
      <td>68</td>
    </tr>
    <tr>
      <th>AAA Batteries (4-pack),Apple Airpods Headphones</th>
      <td>66</td>
    </tr>
    <tr>
      <th>Bose SoundSport Headphones,Lightning Charging Cable</th>
      <td>64</td>
    </tr>
    <tr>
      <th>Google Phone,Bose SoundSport Headphones,Wired Headphones</th>
      <td>63</td>
    </tr>
    <tr>
      <th>Apple Airpods Headphones,Bose SoundSport Headphones</th>
      <td>62</td>
    </tr>
    <tr>
      <th>USB-C Charging Cable,Apple Airpods Headphones</th>
      <td>62</td>
    </tr>
    <tr>
      <th>Lightning Charging Cable,Wired Headphones</th>
      <td>60</td>
    </tr>
    <tr>
      <th>Apple Airpods Headphones,USB-C Charging Cable</th>
      <td>58</td>
    </tr>
    <tr>
      <th>USB-C Charging Cable,27in FHD Monitor</th>
      <td>58</td>
    </tr>
    <tr>
      <th>Apple Airpods Headphones,AA Batteries (4-pack)</th>
      <td>58</td>
    </tr>
    <tr>
      <th>Wired Headphones,Apple Airpods Headphones</th>
      <td>58</td>
    </tr>
    <tr>
      <th>AA Batteries (4-pack),Bose SoundSport Headphones</th>
      <td>56</td>
    </tr>
    <tr>
      <th>Bose SoundSport Headphones,AA Batteries (4-pack)</th>
      <td>54</td>
    </tr>
    <tr>
      <th>Bose SoundSport Headphones,Bose SoundSport Headphones</th>
      <td>54</td>
    </tr>
    <tr>
      <th>USB-C Charging Cable,Bose SoundSport Headphones</th>
      <td>52</td>
    </tr>
    <tr>
      <th>Bose SoundSport Headphones,USB-C Charging Cable</th>
      <td>50</td>
    </tr>
    <tr>
      <th>Bose SoundSport Headphones,Wired Headphones</th>
      <td>48</td>
    </tr>
    <tr>
      <th>Apple Airpods Headphones,Apple Airpods Headphones</th>
      <td>48</td>
    </tr>
    <tr>
      <th>AAA Batteries (4-pack),27in FHD Monitor</th>
      <td>44</td>
    </tr>
    <tr>
      <th>Wired Headphones,Bose SoundSport Headphones</th>
      <td>42</td>
    </tr>
    <tr>
      <th>27in FHD Monitor,AAA Batteries (4-pack)</th>
      <td>42</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,USB-C Charging Cable,Bose SoundSport Headphones</th>
      <td>42</td>
    </tr>
    <tr>
      <th>AAA Batteries (4-pack),Bose SoundSport Headphones</th>
      <td>40</td>
    </tr>
    <tr>
      <th>34in Ultrawide Monitor,AA Batteries (4-pack)</th>
      <td>38</td>
    </tr>
    <tr>
      <th>34in Ultrawide Monitor,Lightning Charging Cable</th>
      <td>36</td>
    </tr>
    <tr>
      <th>Lightning Charging Cable,27in FHD Monitor</th>
      <td>36</td>
    </tr>
    <tr>
      <th>27in FHD Monitor,Lightning Charging Cable</th>
      <td>36</td>
    </tr>
    <tr>
      <th>AA Batteries (4-pack),iPhone</th>
      <td>36</td>
    </tr>
    <tr>
      <th>Wired Headphones,34in Ultrawide Monitor</th>
      <td>34</td>
    </tr>
    <tr>
      <th>Bose SoundSport Headphones,Apple Airpods Headphones</th>
      <td>34</td>
    </tr>
    <tr>
      <th>Lightning Charging Cable,27in 4K Gaming Monitor</th>
      <td>34</td>
    </tr>
    <tr>
      <th>Wired Headphones,27in 4K Gaming Monitor</th>
      <td>34</td>
    </tr>
    <tr>
      <th>ThinkPad Laptop,AAA Batteries (4-pack)</th>
      <td>32</td>
    </tr>
    <tr>
      <th>27in 4K Gaming Monitor,Lightning Charging Cable</th>
      <td>32</td>
    </tr>
    <tr>
      <th>27in 4K Gaming Monitor,AAA Batteries (4-pack)</th>
      <td>30</td>
    </tr>
    <tr>
      <th>27in FHD Monitor,AA Batteries (4-pack)</th>
      <td>30</td>
    </tr>
    <tr>
      <th>Lightning Charging Cable,20in Monitor</th>
      <td>30</td>
    </tr>
    <tr>
      <th>20in Monitor,USB-C Charging Cable</th>
      <td>30</td>
    </tr>
    <tr>
      <th>AAA Batteries (4-pack),27in 4K Gaming Monitor</th>
      <td>30</td>
    </tr>
    <tr>
      <th>34in Ultrawide Monitor,USB-C Charging Cable</th>
      <td>30</td>
    </tr>
    <tr>
      <th>Lightning Charging Cable,34in Ultrawide Monitor</th>
      <td>28</td>
    </tr>
    <tr>
      <th>Lightning Charging Cable,Google Phone</th>
      <td>28</td>
    </tr>
    <tr>
      <th>AAA Batteries (4-pack),iPhone</th>
      <td>28</td>
    </tr>
    <tr>
      <th>AA Batteries (4-pack),27in 4K Gaming Monitor</th>
      <td>28</td>
    </tr>
    <tr>
      <th>Bose SoundSport Headphones,27in FHD Monitor</th>
      <td>26</td>
    </tr>
    <tr>
      <th>AAA Batteries (4-pack),34in Ultrawide Monitor</th>
      <td>26</td>
    </tr>
    <tr>
      <th>Apple Airpods Headphones,iPhone</th>
      <td>26</td>
    </tr>
    <tr>
      <th>Apple Airpods Headphones,Google Phone</th>
      <td>26</td>
    </tr>
    <tr>
      <th>Wired Headphones,iPhone</th>
      <td>26</td>
    </tr>
    <tr>
      <th>iPhone,AAA Batteries (4-pack)</th>
      <td>26</td>
    </tr>
    <tr>
      <th>AA Batteries (4-pack),34in Ultrawide Monitor</th>
      <td>26</td>
    </tr>
    <tr>
      <th>AA Batteries (4-pack),Flatscreen TV</th>
      <td>26</td>
    </tr>
    <tr>
      <th>Apple Airpods Headphones,Macbook Pro Laptop</th>
      <td>24</td>
    </tr>
    <tr>
      <th>Wired Headphones,Macbook Pro Laptop</th>
      <td>24</td>
    </tr>
    <tr>
      <th>Apple Airpods Headphones,27in FHD Monitor</th>
      <td>24</td>
    </tr>
    <tr>
      <th>Apple Airpods Headphones,27in 4K Gaming Monitor</th>
      <td>24</td>
    </tr>
    <tr>
      <th>27in 4K Gaming Monitor,AA Batteries (4-pack)</th>
      <td>24</td>
    </tr>
    <tr>
      <th>27in FHD Monitor,Bose SoundSport Headphones</th>
      <td>24</td>
    </tr>
    <tr>
      <th>iPhone,USB-C Charging Cable</th>
      <td>24</td>
    </tr>
    <tr>
      <th>Macbook Pro Laptop,USB-C Charging Cable</th>
      <td>24</td>
    </tr>
    <tr>
      <th>27in FHD Monitor,USB-C Charging Cable</th>
      <td>24</td>
    </tr>
    <tr>
      <th>USB-C Charging Cable,Google Phone</th>
      <td>24</td>
    </tr>
    <tr>
      <th>27in 4K Gaming Monitor,USB-C Charging Cable</th>
      <td>24</td>
    </tr>
    <tr>
      <th>27in FHD Monitor,Apple Airpods Headphones</th>
      <td>24</td>
    </tr>
    <tr>
      <th>USB-C Charging Cable,iPhone</th>
      <td>24</td>
    </tr>
    <tr>
      <th>20in Monitor,Wired Headphones</th>
      <td>24</td>
    </tr>
    <tr>
      <th>34in Ultrawide Monitor,AAA Batteries (4-pack)</th>
      <td>24</td>
    </tr>
    <tr>
      <th>AA Batteries (4-pack),27in FHD Monitor</th>
      <td>22</td>
    </tr>
    <tr>
      <th>27in 4K Gaming Monitor,Wired Headphones</th>
      <td>22</td>
    </tr>
    <tr>
      <th>iPhone,AA Batteries (4-pack)</th>
      <td>22</td>
    </tr>
    <tr>
      <th>Lightning Charging Cable,Flatscreen TV</th>
      <td>22</td>
    </tr>
    <tr>
      <th>ThinkPad Laptop,Lightning Charging Cable</th>
      <td>22</td>
    </tr>
    <tr>
      <th>34in Ultrawide Monitor,Wired Headphones</th>
      <td>22</td>
    </tr>
    <tr>
      <th>USB-C Charging Cable,27in 4K Gaming Monitor</th>
      <td>22</td>
    </tr>
    <tr>
      <th>Flatscreen TV,AAA Batteries (4-pack)</th>
      <td>22</td>
    </tr>
    <tr>
      <th>AAA Batteries (4-pack),Google Phone</th>
      <td>22</td>
    </tr>
    <tr>
      <th>20in Monitor,Lightning Charging Cable</th>
      <td>22</td>
    </tr>
    <tr>
      <th>USB-C Charging Cable,ThinkPad Laptop</th>
      <td>22</td>
    </tr>
    <tr>
      <th>AAA Batteries (4-pack),ThinkPad Laptop</th>
      <td>22</td>
    </tr>
    <tr>
      <th>Macbook Pro Laptop,Lightning Charging Cable</th>
      <td>22</td>
    </tr>
    <tr>
      <th>Wired Headphones,27in FHD Monitor</th>
      <td>22</td>
    </tr>
    <tr>
      <th>AAA Batteries (4-pack),Macbook Pro Laptop</th>
      <td>22</td>
    </tr>
    <tr>
      <th>Macbook Pro Laptop,Bose SoundSport Headphones</th>
      <td>22</td>
    </tr>
    <tr>
      <th>AA Batteries (4-pack),Google Phone</th>
      <td>22</td>
    </tr>
    <tr>
      <th>USB-C Charging Cable,34in Ultrawide Monitor</th>
      <td>20</td>
    </tr>
    <tr>
      <th>USB-C Charging Cable,20in Monitor</th>
      <td>20</td>
    </tr>
    <tr>
      <th>Google Phone,Lightning Charging Cable</th>
      <td>20</td>
    </tr>
    <tr>
      <th>27in FHD Monitor,Wired Headphones</th>
      <td>20</td>
    </tr>
    <tr>
      <th>27in 4K Gaming Monitor,Apple Airpods Headphones</th>
      <td>20</td>
    </tr>
    <tr>
      <th>Flatscreen TV,Lightning Charging Cable</th>
      <td>20</td>
    </tr>
    <tr>
      <th>AAA Batteries (4-pack),Flatscreen TV</th>
      <td>20</td>
    </tr>
    <tr>
      <th>AA Batteries (4-pack),20in Monitor</th>
      <td>20</td>
    </tr>
    <tr>
      <th>Lightning Charging Cable,Macbook Pro Laptop</th>
      <td>20</td>
    </tr>
    <tr>
      <th>Wired Headphones,ThinkPad Laptop</th>
      <td>20</td>
    </tr>
    <tr>
      <th>USB-C Charging Cable,Flatscreen TV</th>
      <td>20</td>
    </tr>
    <tr>
      <th>Bose SoundSport Headphones,34in Ultrawide Monitor</th>
      <td>20</td>
    </tr>
    <tr>
      <th>Google Phone,AA Batteries (4-pack)</th>
      <td>20</td>
    </tr>
    <tr>
      <th>Bose SoundSport Headphones,27in 4K Gaming Monitor</th>
      <td>20</td>
    </tr>
    <tr>
      <th>27in 4K Gaming Monitor,Bose SoundSport Headphones</th>
      <td>18</td>
    </tr>
    <tr>
      <th>27in FHD Monitor,27in FHD Monitor</th>
      <td>18</td>
    </tr>
    <tr>
      <th>20in Monitor,Bose SoundSport Headphones</th>
      <td>18</td>
    </tr>
    <tr>
      <th>USB-C Charging Cable,Macbook Pro Laptop</th>
      <td>18</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,AA Batteries (4-pack)</th>
      <td>18</td>
    </tr>
    <tr>
      <th>Apple Airpods Headphones,ThinkPad Laptop</th>
      <td>18</td>
    </tr>
    <tr>
      <th>ThinkPad Laptop,USB-C Charging Cable</th>
      <td>18</td>
    </tr>
    <tr>
      <th>ThinkPad Laptop,Bose SoundSport Headphones</th>
      <td>18</td>
    </tr>
    <tr>
      <th>Macbook Pro Laptop,AA Batteries (4-pack)</th>
      <td>18</td>
    </tr>
    <tr>
      <th>Lightning Charging Cable,ThinkPad Laptop</th>
      <td>18</td>
    </tr>
    <tr>
      <th>Bose SoundSport Headphones,Flatscreen TV</th>
      <td>18</td>
    </tr>
    <tr>
      <th>AA Batteries (4-pack),ThinkPad Laptop</th>
      <td>18</td>
    </tr>
    <tr>
      <th>Lightning Charging Cable,iPhone</th>
      <td>18</td>
    </tr>
    <tr>
      <th>AAA Batteries (4-pack),20in Monitor</th>
      <td>16</td>
    </tr>
    <tr>
      <th>Apple Airpods Headphones,Flatscreen TV</th>
      <td>16</td>
    </tr>
    <tr>
      <th>AA Batteries (4-pack),Macbook Pro Laptop</th>
      <td>16</td>
    </tr>
    <tr>
      <th>Google Phone,AAA Batteries (4-pack)</th>
      <td>16</td>
    </tr>
    <tr>
      <th>Flatscreen TV,AA Batteries (4-pack)</th>
      <td>16</td>
    </tr>
    <tr>
      <th>Wired Headphones,Google Phone</th>
      <td>16</td>
    </tr>
    <tr>
      <th>ThinkPad Laptop,AA Batteries (4-pack)</th>
      <td>16</td>
    </tr>
    <tr>
      <th>Bose SoundSport Headphones,Google Phone</th>
      <td>16</td>
    </tr>
    <tr>
      <th>34in Ultrawide Monitor,Apple Airpods Headphones</th>
      <td>16</td>
    </tr>
    <tr>
      <th>Macbook Pro Laptop,Wired Headphones</th>
      <td>14</td>
    </tr>
    <tr>
      <th>Wired Headphones,Flatscreen TV</th>
      <td>14</td>
    </tr>
    <tr>
      <th>Wired Headphones,20in Monitor</th>
      <td>14</td>
    </tr>
    <tr>
      <th>ThinkPad Laptop,Apple Airpods Headphones</th>
      <td>14</td>
    </tr>
    <tr>
      <th>Macbook Pro Laptop,27in 4K Gaming Monitor</th>
      <td>14</td>
    </tr>
    <tr>
      <th>Macbook Pro Laptop,Apple Airpods Headphones</th>
      <td>14</td>
    </tr>
    <tr>
      <th>Macbook Pro Laptop,AAA Batteries (4-pack)</th>
      <td>14</td>
    </tr>
    <tr>
      <th>Flatscreen TV,USB-C Charging Cable</th>
      <td>14</td>
    </tr>
    <tr>
      <th>34in Ultrawide Monitor,iPhone</th>
      <td>14</td>
    </tr>
    <tr>
      <th>34in Ultrawide Monitor,34in Ultrawide Monitor</th>
      <td>14</td>
    </tr>
    <tr>
      <th>Bose SoundSport Headphones,iPhone</th>
      <td>14</td>
    </tr>
    <tr>
      <th>20in Monitor,Apple Airpods Headphones</th>
      <td>14</td>
    </tr>
    <tr>
      <th>27in FHD Monitor,Macbook Pro Laptop</th>
      <td>12</td>
    </tr>
    <tr>
      <th>Flatscreen TV,Flatscreen TV</th>
      <td>12</td>
    </tr>
    <tr>
      <th>Wired Headphones,Vareebadd Phone</th>
      <td>12</td>
    </tr>
    <tr>
      <th>27in 4K Gaming Monitor,Macbook Pro Laptop</th>
      <td>12</td>
    </tr>
    <tr>
      <th>iPhone,Lightning Charging Cable,Apple Airpods Headphones,Wired Headphones</th>
      <td>12</td>
    </tr>
    <tr>
      <th>USB-C Charging Cable,Vareebadd Phone</th>
      <td>12</td>
    </tr>
    <tr>
      <th>27in 4K Gaming Monitor,34in Ultrawide Monitor</th>
      <td>12</td>
    </tr>
    <tr>
      <th>Apple Airpods Headphones,Vareebadd Phone</th>
      <td>12</td>
    </tr>
    <tr>
      <th>Bose SoundSport Headphones,20in Monitor</th>
      <td>12</td>
    </tr>
    <tr>
      <th>34in Ultrawide Monitor,Bose SoundSport Headphones</th>
      <td>12</td>
    </tr>
    <tr>
      <th>Apple Airpods Headphones,34in Ultrawide Monitor</th>
      <td>12</td>
    </tr>
    <tr>
      <th>Apple Airpods Headphones,20in Monitor</th>
      <td>12</td>
    </tr>
    <tr>
      <th>20in Monitor,AA Batteries (4-pack)</th>
      <td>12</td>
    </tr>
    <tr>
      <th>Google Phone,USB-C Charging Cable,Bose SoundSport Headphones,Wired Headphones</th>
      <td>12</td>
    </tr>
    <tr>
      <th>27in 4K Gaming Monitor,27in 4K Gaming Monitor</th>
      <td>10</td>
    </tr>
    <tr>
      <th>Flatscreen TV,Apple Airpods Headphones</th>
      <td>10</td>
    </tr>
    <tr>
      <th>Flatscreen TV,34in Ultrawide Monitor</th>
      <td>10</td>
    </tr>
    <tr>
      <th>iPhone,27in 4K Gaming Monitor</th>
      <td>10</td>
    </tr>
    <tr>
      <th>iPhone,34in Ultrawide Monitor</th>
      <td>10</td>
    </tr>
    <tr>
      <th>34in Ultrawide Monitor,27in FHD Monitor</th>
      <td>10</td>
    </tr>
    <tr>
      <th>27in FHD Monitor,34in Ultrawide Monitor</th>
      <td>10</td>
    </tr>
    <tr>
      <th>27in 4K Gaming Monitor,Google Phone</th>
      <td>10</td>
    </tr>
    <tr>
      <th>Google Phone,iPhone</th>
      <td>10</td>
    </tr>
    <tr>
      <th>iPhone,Flatscreen TV</th>
      <td>10</td>
    </tr>
    <tr>
      <th>iPhone,Apple Airpods Headphones,AAA Batteries (4-pack)</th>
      <td>9</td>
    </tr>
    <tr>
      <th>Google Phone,USB-C Charging Cable,AAA Batteries (4-pack)</th>
      <td>9</td>
    </tr>
    <tr>
      <th>iPhone,Lightning Charging Cable,Lightning Charging Cable</th>
      <td>9</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,Bose SoundSport Headphones,Wired Headphones</th>
      <td>9</td>
    </tr>
    <tr>
      <th>Bose SoundSport Headphones,Macbook Pro Laptop</th>
      <td>8</td>
    </tr>
    <tr>
      <th>Flatscreen TV,27in FHD Monitor</th>
      <td>8</td>
    </tr>
    <tr>
      <th>Macbook Pro Laptop,Google Phone</th>
      <td>8</td>
    </tr>
    <tr>
      <th>Macbook Pro Laptop,34in Ultrawide Monitor</th>
      <td>8</td>
    </tr>
    <tr>
      <th>27in FHD Monitor,ThinkPad Laptop</th>
      <td>8</td>
    </tr>
    <tr>
      <th>ThinkPad Laptop,Wired Headphones</th>
      <td>8</td>
    </tr>
    <tr>
      <th>Bose SoundSport Headphones,ThinkPad Laptop</th>
      <td>8</td>
    </tr>
    <tr>
      <th>ThinkPad Laptop,Flatscreen TV</th>
      <td>8</td>
    </tr>
    <tr>
      <th>Flatscreen TV,Macbook Pro Laptop</th>
      <td>8</td>
    </tr>
    <tr>
      <th>Lightning Charging Cable,LG Washing Machine</th>
      <td>8</td>
    </tr>
    <tr>
      <th>AAA Batteries (4-pack),Vareebadd Phone</th>
      <td>8</td>
    </tr>
    <tr>
      <th>27in FHD Monitor,27in 4K Gaming Monitor</th>
      <td>8</td>
    </tr>
    <tr>
      <th>iPhone,ThinkPad Laptop</th>
      <td>8</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,USB-C Charging Cable,Bose SoundSport Headphones,Wired Headphones</th>
      <td>8</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,Google Phone</th>
      <td>8</td>
    </tr>
    <tr>
      <th>20in Monitor,Macbook Pro Laptop</th>
      <td>8</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,Apple Airpods Headphones</th>
      <td>8</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,34in Ultrawide Monitor</th>
      <td>8</td>
    </tr>
    <tr>
      <th>27in 4K Gaming Monitor,27in FHD Monitor</th>
      <td>8</td>
    </tr>
    <tr>
      <th>LG Dryer,AA Batteries (4-pack)</th>
      <td>8</td>
    </tr>
    <tr>
      <th>Google Phone,Apple Airpods Headphones</th>
      <td>8</td>
    </tr>
    <tr>
      <th>iPhone,Bose SoundSport Headphones</th>
      <td>8</td>
    </tr>
    <tr>
      <th>Flatscreen TV,iPhone</th>
      <td>8</td>
    </tr>
    <tr>
      <th>Flatscreen TV,Wired Headphones</th>
      <td>8</td>
    </tr>
    <tr>
      <th>27in 4K Gaming Monitor,ThinkPad Laptop</th>
      <td>8</td>
    </tr>
    <tr>
      <th>LG Washing Machine,AAA Batteries (4-pack)</th>
      <td>8</td>
    </tr>
    <tr>
      <th>Google Phone,27in FHD Monitor</th>
      <td>8</td>
    </tr>
    <tr>
      <th>34in Ultrawide Monitor,ThinkPad Laptop</th>
      <td>6</td>
    </tr>
    <tr>
      <th>ThinkPad Laptop,iPhone</th>
      <td>6</td>
    </tr>
    <tr>
      <th>Macbook Pro Laptop,iPhone</th>
      <td>6</td>
    </tr>
    <tr>
      <th>34in Ultrawide Monitor,Macbook Pro Laptop</th>
      <td>6</td>
    </tr>
    <tr>
      <th>20in Monitor,AAA Batteries (4-pack)</th>
      <td>6</td>
    </tr>
    <tr>
      <th>iPhone,Lightning Charging Cable,USB-C Charging Cable</th>
      <td>6</td>
    </tr>
    <tr>
      <th>ThinkPad Laptop,Google Phone</th>
      <td>6</td>
    </tr>
    <tr>
      <th>iPhone,Vareebadd Phone</th>
      <td>6</td>
    </tr>
    <tr>
      <th>27in 4K Gaming Monitor,iPhone</th>
      <td>6</td>
    </tr>
    <tr>
      <th>Macbook Pro Laptop,ThinkPad Laptop</th>
      <td>6</td>
    </tr>
    <tr>
      <th>iPhone,Macbook Pro Laptop</th>
      <td>6</td>
    </tr>
    <tr>
      <th>27in FHD Monitor,20in Monitor</th>
      <td>6</td>
    </tr>
    <tr>
      <th>27in 4K Gaming Monitor,Flatscreen TV</th>
      <td>6</td>
    </tr>
    <tr>
      <th>34in Ultrawide Monitor,Flatscreen TV</th>
      <td>6</td>
    </tr>
    <tr>
      <th>Google Phone,ThinkPad Laptop</th>
      <td>6</td>
    </tr>
    <tr>
      <th>Macbook Pro Laptop,Macbook Pro Laptop</th>
      <td>6</td>
    </tr>
    <tr>
      <th>Macbook Pro Laptop,27in FHD Monitor</th>
      <td>6</td>
    </tr>
    <tr>
      <th>Google Phone,USB-C Charging Cable,AA Batteries (4-pack)</th>
      <td>6</td>
    </tr>
    <tr>
      <th>Google Phone,Google Phone</th>
      <td>6</td>
    </tr>
    <tr>
      <th>Flatscreen TV,Google Phone</th>
      <td>6</td>
    </tr>
    <tr>
      <th>Flatscreen TV,Bose SoundSport Headphones</th>
      <td>6</td>
    </tr>
    <tr>
      <th>Apple Airpods Headphones,LG Dryer</th>
      <td>6</td>
    </tr>
    <tr>
      <th>20in Monitor,20in Monitor</th>
      <td>6</td>
    </tr>
    <tr>
      <th>AA Batteries (4-pack),Vareebadd Phone</th>
      <td>6</td>
    </tr>
    <tr>
      <th>iPhone,Lightning Charging Cable,AA Batteries (4-pack)</th>
      <td>6</td>
    </tr>
    <tr>
      <th>Wired Headphones,LG Washing Machine</th>
      <td>6</td>
    </tr>
    <tr>
      <th>iPhone,Lightning Charging Cable,Apple Airpods Headphones,Wired Headphones,Google Phone</th>
      <td>5</td>
    </tr>
    <tr>
      <th>34in Ultrawide Monitor,Google Phone</th>
      <td>4</td>
    </tr>
    <tr>
      <th>Google Phone,USB-C Charging Cable,Wired Headphones,iPhone</th>
      <td>4</td>
    </tr>
    <tr>
      <th>Google Phone,USB-C Charging Cable,Wired Headphones,Wired Headphones</th>
      <td>4</td>
    </tr>
    <tr>
      <th>Google Phone,USB-C Charging Cable,Wired Headphones,USB-C Charging Cable</th>
      <td>4</td>
    </tr>
    <tr>
      <th>Google Phone,USB-C Charging Cable,Wired Headphones,Apple Airpods Headphones</th>
      <td>4</td>
    </tr>
    <tr>
      <th>27in 4K Gaming Monitor,20in Monitor</th>
      <td>4</td>
    </tr>
    <tr>
      <th>Google Phone,USB-C Charging Cable,Wired Headphones,AA Batteries (4-pack)</th>
      <td>4</td>
    </tr>
    <tr>
      <th>20in Monitor,ThinkPad Laptop</th>
      <td>4</td>
    </tr>
    <tr>
      <th>Google Phone,USB-C Charging Cable,Wired Headphones,27in FHD Monitor</th>
      <td>4</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,AAA Batteries (4-pack)</th>
      <td>4</td>
    </tr>
    <tr>
      <th>iPhone,20in Monitor</th>
      <td>4</td>
    </tr>
    <tr>
      <th>20in Monitor,27in FHD Monitor</th>
      <td>4</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,Flatscreen TV</th>
      <td>4</td>
    </tr>
    <tr>
      <th>20in Monitor,Google Phone</th>
      <td>4</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,ThinkPad Laptop</th>
      <td>4</td>
    </tr>
    <tr>
      <th>Google Phone,USB-C Charging Cable,Bose SoundSport Headphones,34in Ultrawide Monitor</th>
      <td>4</td>
    </tr>
    <tr>
      <th>Google Phone,Macbook Pro Laptop</th>
      <td>4</td>
    </tr>
    <tr>
      <th>Macbook Pro Laptop,LG Washing Machine</th>
      <td>4</td>
    </tr>
    <tr>
      <th>Macbook Pro Laptop,20in Monitor</th>
      <td>4</td>
    </tr>
    <tr>
      <th>Google Phone,34in Ultrawide Monitor</th>
      <td>4</td>
    </tr>
    <tr>
      <th>LG Washing Machine,Bose SoundSport Headphones</th>
      <td>4</td>
    </tr>
    <tr>
      <th>Lightning Charging Cable,LG Dryer</th>
      <td>4</td>
    </tr>
    <tr>
      <th>Bose SoundSport Headphones,Vareebadd Phone</th>
      <td>4</td>
    </tr>
    <tr>
      <th>ThinkPad Laptop,ThinkPad Laptop</th>
      <td>4</td>
    </tr>
    <tr>
      <th>iPhone,Lightning Charging Cable,Wired Headphones,AA Batteries (4-pack)</th>
      <td>4</td>
    </tr>
    <tr>
      <th>Google Phone,20in Monitor</th>
      <td>4</td>
    </tr>
    <tr>
      <th>Flatscreen TV,27in 4K Gaming Monitor</th>
      <td>4</td>
    </tr>
    <tr>
      <th>ThinkPad Laptop,27in FHD Monitor</th>
      <td>4</td>
    </tr>
    <tr>
      <th>iPhone,Lightning Charging Cable,Wired Headphones,USB-C Charging Cable</th>
      <td>4</td>
    </tr>
    <tr>
      <th>27in FHD Monitor,LG Dryer</th>
      <td>4</td>
    </tr>
    <tr>
      <th>Lightning Charging Cable,Vareebadd Phone</th>
      <td>4</td>
    </tr>
    <tr>
      <th>27in FHD Monitor,Flatscreen TV</th>
      <td>4</td>
    </tr>
    <tr>
      <th>Flatscreen TV,ThinkPad Laptop</th>
      <td>4</td>
    </tr>
    <tr>
      <th>LG Washing Machine,Lightning Charging Cable</th>
      <td>4</td>
    </tr>
    <tr>
      <th>AA Batteries (4-pack),LG Dryer</th>
      <td>4</td>
    </tr>
    <tr>
      <th>ThinkPad Laptop,Macbook Pro Laptop</th>
      <td>4</td>
    </tr>
    <tr>
      <th>iPhone,Wired Headphones,Lightning Charging Cable</th>
      <td>3</td>
    </tr>
    <tr>
      <th>iPhone,Lightning Charging Cable,34in Ultrawide Monitor</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,Wired Headphones,iPhone</th>
      <td>3</td>
    </tr>
    <tr>
      <th>iPhone,Lightning Charging Cable,Flatscreen TV</th>
      <td>3</td>
    </tr>
    <tr>
      <th>iPhone,Lightning Charging Cable,Vareebadd Phone</th>
      <td>3</td>
    </tr>
    <tr>
      <th>iPhone,Lightning Charging Cable,27in 4K Gaming Monitor</th>
      <td>3</td>
    </tr>
    <tr>
      <th>iPhone,Lightning Charging Cable,Google Phone</th>
      <td>3</td>
    </tr>
    <tr>
      <th>iPhone,Lightning Charging Cable,iPhone</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,Wired Headphones,Apple Airpods Headphones</th>
      <td>3</td>
    </tr>
    <tr>
      <th>iPhone,Apple Airpods Headphones,Bose SoundSport Headphones</th>
      <td>3</td>
    </tr>
    <tr>
      <th>iPhone,Lightning Charging Cable,AAA Batteries (4-pack)</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Google Phone,USB-C Charging Cable,Vareebadd Phone</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,Wired Headphones,27in 4K Gaming Monitor</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Google Phone,Wired Headphones,AA Batteries (4-pack)</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Google Phone,Wired Headphones,USB-C Charging Cable</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,USB-C Charging Cable,iPhone</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Google Phone,USB-C Charging Cable,USB-C Charging Cable</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Google Phone,USB-C Charging Cable,Lightning Charging Cable</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Google Phone,USB-C Charging Cable,Apple Airpods Headphones</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Google Phone,USB-C Charging Cable,27in FHD Monitor</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Google Phone,Bose SoundSport Headphones,Lightning Charging Cable</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Google Phone,Bose SoundSport Headphones,Apple Airpods Headphones</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Google Phone,Bose SoundSport Headphones,27in FHD Monitor</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Google Phone,Wired Headphones,Macbook Pro Laptop</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,USB-C Charging Cable,Apple Airpods Headphones</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,Bose SoundSport Headphones,Flatscreen TV</th>
      <td>3</td>
    </tr>
    <tr>
      <th>27in FHD Monitor,Vareebadd Phone</th>
      <td>2</td>
    </tr>
    <tr>
      <th>27in FHD Monitor,iPhone</th>
      <td>2</td>
    </tr>
    <tr>
      <th>20in Monitor,34in Ultrawide Monitor</th>
      <td>2</td>
    </tr>
    <tr>
      <th>iPhone,Google Phone</th>
      <td>2</td>
    </tr>
    <tr>
      <th>iPhone,LG Washing Machine</th>
      <td>2</td>
    </tr>
    <tr>
      <th>20in Monitor,Flatscreen TV</th>
      <td>2</td>
    </tr>
    <tr>
      <th>20in Monitor,LG Washing Machine</th>
      <td>2</td>
    </tr>
    <tr>
      <th>20in Monitor,iPhone</th>
      <td>2</td>
    </tr>
    <tr>
      <th>Google Phone,Flatscreen TV</th>
      <td>2</td>
    </tr>
    <tr>
      <th>27in 4K Gaming Monitor,LG Dryer</th>
      <td>2</td>
    </tr>
    <tr>
      <th>27in 4K Gaming Monitor,Vareebadd Phone</th>
      <td>2</td>
    </tr>
    <tr>
      <th>27in FHD Monitor,Google Phone</th>
      <td>2</td>
    </tr>
    <tr>
      <th>Google Phone,27in 4K Gaming Monitor</th>
      <td>2</td>
    </tr>
    <tr>
      <th>Flatscreen TV,20in Monitor</th>
      <td>2</td>
    </tr>
    <tr>
      <th>27in FHD Monitor,LG Washing Machine</th>
      <td>2</td>
    </tr>
    <tr>
      <th>34in Ultrawide Monitor,LG Washing Machine</th>
      <td>2</td>
    </tr>
    <tr>
      <th>34in Ultrawide Monitor,20in Monitor</th>
      <td>2</td>
    </tr>
    <tr>
      <th>AAA Batteries (4-pack),LG Dryer</th>
      <td>2</td>
    </tr>
    <tr>
      <th>LG Dryer,27in 4K Gaming Monitor</th>
      <td>2</td>
    </tr>
    <tr>
      <th>LG Dryer,27in FHD Monitor</th>
      <td>2</td>
    </tr>
    <tr>
      <th>LG Dryer,AAA Batteries (4-pack)</th>
      <td>2</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,iPhone</th>
      <td>2</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,Lightning Charging Cable</th>
      <td>2</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,27in FHD Monitor</th>
      <td>2</td>
    </tr>
    <tr>
      <th>Vareebadd Phone,27in 4K Gaming Monitor</th>
      <td>2</td>
    </tr>
    <tr>
      <th>USB-C Charging Cable,LG Dryer</th>
      <td>2</td>
    </tr>
    <tr>
      <th>ThinkPad Laptop,Vareebadd Phone</th>
      <td>2</td>
    </tr>
    <tr>
      <th>ThinkPad Laptop,LG Dryer</th>
      <td>2</td>
    </tr>
    <tr>
      <th>ThinkPad Laptop,34in Ultrawide Monitor</th>
      <td>2</td>
    </tr>
    <tr>
      <th>ThinkPad Laptop,27in 4K Gaming Monitor</th>
      <td>2</td>
    </tr>
    <tr>
      <th>Macbook Pro Laptop,Flatscreen TV</th>
      <td>2</td>
    </tr>
    <tr>
      <th>LG Washing Machine,iPhone</th>
      <td>2</td>
    </tr>
    <tr>
      <th>LG Washing Machine,Wired Headphones</th>
      <td>2</td>
    </tr>
    <tr>
      <th>LG Washing Machine,Google Phone</th>
      <td>2</td>
    </tr>
    <tr>
      <th>LG Washing Machine,Apple Airpods Headphones</th>
      <td>2</td>
    </tr>
    <tr>
      <th>LG Washing Machine,AA Batteries (4-pack)</th>
      <td>2</td>
    </tr>
    <tr>
      <th>LG Washing Machine,27in 4K Gaming Monitor</th>
      <td>2</td>
    </tr>
    <tr>
      <th>LG Washing Machine,20in Monitor</th>
      <td>2</td>
    </tr>
    <tr>
      <th>LG Dryer,Wired Headphones</th>
      <td>2</td>
    </tr>
    <tr>
      <th>LG Dryer,Vareebadd Phone</th>
      <td>2</td>
    </tr>
    <tr>
      <th>iPhone,27in FHD Monitor</th>
      <td>2</td>
    </tr>
    <tr>
      <th>LG Dryer,Lightning Charging Cable</th>
      <td>2</td>
    </tr>
    <tr>
      <th>LG Dryer,Google Phone</th>
      <td>2</td>
    </tr>
    <tr>
      <th>LG Dryer,Flatscreen TV</th>
      <td>2</td>
    </tr>
    <tr>
      <th>iPhone,iPhone</th>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>



#### In Different Combinations


```python
from itertools import combinations
from collections import Counter

count= Counter() 
for row in df["Grouped"]:
    row_list = row.split(",")
    count.update(Counter(combinations(row_list,2)))
for key, value in count.most_common(20):
    print(key, value)

```

    ('iPhone', 'Lightning Charging Cable') 2140
    ('Google Phone', 'USB-C Charging Cable') 2116
    ('iPhone', 'Wired Headphones') 987
    ('Google Phone', 'Wired Headphones') 949
    ('iPhone', 'Apple Airpods Headphones') 799
    ('Vareebadd Phone', 'USB-C Charging Cable') 773
    ('Google Phone', 'Bose SoundSport Headphones') 503
    ('USB-C Charging Cable', 'Wired Headphones') 452
    ('Vareebadd Phone', 'Wired Headphones') 327
    ('Lightning Charging Cable', 'Wired Headphones') 253
    ('Lightning Charging Cable', 'Apple Airpods Headphones') 214
    ('USB-C Charging Cable', 'Bose SoundSport Headphones') 211
    ('Vareebadd Phone', 'Bose SoundSport Headphones') 182
    ('Apple Airpods Headphones', 'Wired Headphones') 170
    ('Bose SoundSport Headphones', 'Wired Headphones') 140
    ('Lightning Charging Cable', 'USB-C Charging Cable') 120
    ('Lightning Charging Cable', 'AA Batteries (4-pack)') 114
    ('Lightning Charging Cable', 'Lightning Charging Cable') 111
    ('AA Batteries (4-pack)', 'Lightning Charging Cable') 102
    ('AAA Batteries (4-pack)', 'USB-C Charging Cable') 100
    
